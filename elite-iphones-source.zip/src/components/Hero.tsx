import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import heroImg from "@/assets/hero-iphone.png";

export const Hero = () => {
  return (
    <section className="relative overflow-hidden bg-hero">
      <div className="container mx-auto px-6 pt-16 pb-8 md:pt-24 md:pb-16 text-center">
        <p className="text-sm font-medium text-accent animate-fade-in">New • iPhone 16 Pro</p>
        <h1 className="mt-4 text-5xl md:text-7xl lg:text-8xl font-semibold text-gradient animate-fade-in-up">
          Discover the Future
          <br />
          <span className="text-foreground">with iPhone</span>
        </h1>
        <p className="mt-6 max-w-xl mx-auto text-lg text-muted-foreground animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
          Forged in titanium. Powered by A18 Pro. The most advanced iPhone, now at Elite.
        </p>
        <div className="mt-8 flex items-center justify-center gap-3 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
          <Button size="lg" className="rounded-full px-7 h-12">
            Shop iPhone <ArrowRight className="ml-1 h-4 w-4" />
          </Button>
          <Button size="lg" variant="ghost" className="rounded-full px-7 h-12 text-accent hover:text-accent">
            Learn more →
          </Button>
        </div>

        <div className="relative mt-12 md:mt-16 mx-auto max-w-4xl">
          <div className="absolute inset-0 bg-glow animate-glow-pulse" aria-hidden />
          <img
            src={heroImg}
            alt="iPhone 16 Pro in Natural Titanium"
            width={1280}
            height={1280}
            className="relative mx-auto w-full max-w-2xl animate-float drop-shadow-2xl"
          />
        </div>
      </div>
    </section>
  );
};
