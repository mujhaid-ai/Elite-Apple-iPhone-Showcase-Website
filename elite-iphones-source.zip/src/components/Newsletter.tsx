import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { useState } from "react";

export const Newsletter = () => {
  const [email, setEmail] = useState("");
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Please enter a valid email");
      return;
    }
    toast.success("You're subscribed. Welcome to Elite.");
    setEmail("");
  };
  return (
    <section className="container mx-auto px-6 py-20">
      <div className="rounded-3xl bg-gradient-to-br from-foreground to-graphite text-background p-10 md:p-16 text-center">
        <h2 className="text-3xl md:text-4xl font-semibold">Stay in the loop</h2>
        <p className="mt-3 opacity-80 max-w-md mx-auto">New launches, exclusive drops, and member-only deals — straight to your inbox.</p>
        <form onSubmit={submit} className="mt-8 flex max-w-md mx-auto gap-2">
          <Input
            type="email"
            placeholder="your@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            maxLength={255}
            className="rounded-full bg-background/10 border-background/20 text-background placeholder:text-background/50 h-12"
          />
          <Button type="submit" variant="secondary" className="rounded-full h-12 px-6">Subscribe</Button>
        </form>
      </div>
    </section>
  );
};
