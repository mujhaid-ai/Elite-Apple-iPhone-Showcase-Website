import { ProductCard, type Product } from "./ProductCard";
import iphone16pro from "@/assets/iphone-16-pro.png";
import iphone16 from "@/assets/iphone-16.png";
import iphone15pro from "@/assets/iphone-15-pro.png";

const products: Product[] = [
  { name: "iPhone 16 Pro", tagline: "Titanium. So strong. So light.", price: "Rs 459,999", oldPrice: "Rs 489,999", image: iphone16pro, badge: "New" },
  { name: "iPhone 16", tagline: "Hello, Apple Intelligence.", price: "Rs 329,999", image: iphone16 },
  { name: "iPhone 15 Pro", tagline: "Pro. Beyond.", price: "Rs 379,999", oldPrice: "Rs 419,999", image: iphone15pro, badge: "-10%" },
];

export const FeaturedProducts = () => {
  return (
    <section id="iphone" className="container mx-auto px-6 py-20 md:py-28">
      <div className="mb-12 text-center">
        <p className="text-sm font-medium text-accent">Featured</p>
        <h2 className="mt-2 text-4xl md:text-5xl font-semibold text-gradient">The latest. Take a look.</h2>
      </div>
      <div className="grid gap-6 md:grid-cols-3">
        {products.map((p) => <ProductCard key={p.name} product={p} />)}
      </div>
    </section>
  );
};
