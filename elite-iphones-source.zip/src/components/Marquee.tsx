const items = [
  "Free Delivery Across Pakistan",
  "1-Year Warranty",
  "100% Original Apple Products",
  "Trade-In & Save up to Rs 80,000",
  "Easy Installments Available",
  "PTA Approved",
];

export const Marquee = () => {
  return (
    <div className="border-y border-border bg-secondary/40 overflow-hidden py-4">
      <div className="flex animate-marquee whitespace-nowrap">
        {[...items, ...items].map((t, i) => (
          <span key={i} className="mx-8 text-sm font-medium text-muted-foreground flex items-center gap-8">
            {t}
            <span className="h-1 w-1 rounded-full bg-muted-foreground/40" />
          </span>
        ))}
      </div>
    </div>
  );
};
