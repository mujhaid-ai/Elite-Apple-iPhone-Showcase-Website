import { Button } from "@/components/ui/button";

export interface Product {
  name: string;
  tagline: string;
  price: string;
  oldPrice?: string;
  image: string;
  badge?: string;
}

export const ProductCard = ({ product }: { product: Product }) => {
  return (
    <article className="group relative flex flex-col rounded-3xl bg-card p-6 md:p-8 shadow-card-elite transition-smooth hover:shadow-product hover:-translate-y-1">
      {product.badge && (
        <span className="absolute top-5 left-5 z-10 rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-foreground">
          {product.badge}
        </span>
      )}
      <div className="aspect-square overflow-hidden flex items-center justify-center">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          width={900}
          height={900}
          className="h-full w-full object-contain transition-smooth group-hover:scale-105"
        />
      </div>
      <div className="mt-6 text-center">
        <h3 className="text-xl font-semibold">{product.name}</h3>
        <p className="mt-1 text-sm text-muted-foreground">{product.tagline}</p>
        <div className="mt-4 flex items-center justify-center gap-2">
          <span className="text-lg font-semibold">{product.price}</span>
          {product.oldPrice && <span className="text-sm text-muted-foreground line-through">{product.oldPrice}</span>}
        </div>
        <div className="mt-5 flex items-center justify-center gap-2">
          <Button size="sm" className="rounded-full px-5">Buy</Button>
          <Button size="sm" variant="ghost" className="rounded-full text-accent hover:text-accent">Learn more →</Button>
        </div>
      </div>
    </article>
  );
};
