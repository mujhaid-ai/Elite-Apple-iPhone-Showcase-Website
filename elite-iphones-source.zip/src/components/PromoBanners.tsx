import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export const PromoBanners = () => {
  return (
    <section className="container mx-auto px-6 py-12 grid gap-6 md:grid-cols-2">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-graphite to-foreground p-10 md:p-14 text-background min-h-[320px] flex flex-col justify-end">
        <div className="absolute top-6 right-6 h-40 w-40 rounded-full bg-accent/30 blur-3xl" />
        <p className="text-sm uppercase tracking-widest opacity-70">Trade-In</p>
        <h3 className="mt-3 text-3xl md:text-4xl font-semibold">Upgrade & save up to <span className="text-accent">Rs 80,000</span></h3>
        <p className="mt-3 max-w-md opacity-80">Trade in your old iPhone for credit toward a new one. Quick valuation, instant offer.</p>
        <Button variant="secondary" className="mt-6 rounded-full w-fit">
          Get your estimate <ArrowRight className="ml-1 h-4 w-4" />
        </Button>
      </div>
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-secondary to-silver/40 p-10 md:p-14 min-h-[320px] flex flex-col justify-end">
        <div className="absolute top-6 right-6 h-40 w-40 rounded-full bg-accent/20 blur-3xl" />
        <p className="text-sm uppercase tracking-widest text-accent">Limited offer</p>
        <h3 className="mt-3 text-3xl md:text-4xl font-semibold text-foreground">0% Installments for 12 months</h3>
        <p className="mt-3 max-w-md text-muted-foreground">Own it now, pay over time. Available on all major banks.</p>
        <Button className="mt-6 rounded-full w-fit">Shop now</Button>
      </div>
    </section>
  );
};
