import { Star } from "lucide-react";

const reviews = [
  { name: "Ahmed K.", city: "Karachi", text: "Got my iPhone 16 Pro delivered next day. Sealed box, PTA approved, exactly as described. Best iPhone store in Pakistan." },
  { name: "Sara M.", city: "Lahore", text: "Smooth trade-in process. They gave me a fair price for my 13 Pro and I walked away with a 16. Highly recommend." },
  { name: "Bilal R.", city: "Islamabad", text: "Customer service is on another level. Answered all my questions on WhatsApp before I bought. Genuine, reliable, premium." },
];

export const Testimonials = () => {
  return (
    <section className="container mx-auto px-6 py-20">
      <div className="mb-14 text-center">
        <h2 className="text-4xl md:text-5xl font-semibold text-gradient">Loved across Pakistan</h2>
        <div className="mt-4 flex items-center justify-center gap-1 text-accent">
          {[...Array(5)].map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}
          <span className="ml-2 text-sm text-muted-foreground">4.9 average from 2,400+ reviews</span>
        </div>
      </div>
      <div className="grid gap-6 md:grid-cols-3">
        {reviews.map((r) => (
          <figure key={r.name} className="rounded-3xl bg-card p-8 shadow-card-elite">
            <div className="flex gap-1 text-accent">
              {[...Array(5)].map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}
            </div>
            <blockquote className="mt-4 text-foreground/90 leading-relaxed">"{r.text}"</blockquote>
            <figcaption className="mt-6 text-sm">
              <span className="font-semibold">{r.name}</span>
              <span className="text-muted-foreground"> · {r.city}</span>
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
};
