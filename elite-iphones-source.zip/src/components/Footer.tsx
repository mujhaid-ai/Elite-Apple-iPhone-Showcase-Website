import { Instagram, Facebook, Twitter, Youtube, MapPin, MessageCircle } from "lucide-react";

const cols = [
  { title: "Shop", links: ["iPhone 16 Pro", "iPhone 16", "iPhone 15", "Refurbished", "Accessories"] },
  { title: "Support", links: ["Contact us", "Warranty", "Shipping", "Returns", "FAQ"] },
  { title: "Company", links: ["About", "Stores", "Careers", "Blog", "Press"] },
  { title: "Pay with", links: ["Cash on Delivery", "Credit Card", "EasyPaisa", "JazzCash", "Bank Transfer"] },
];

export const Footer = () => {
  return (
    <footer id="support" className="border-t border-border bg-secondary/40 pt-16 pb-8">
      <div className="container mx-auto px-6">
        <div className="grid gap-10 md:grid-cols-5">
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 font-semibold">
              <span className="inline-block h-6 w-6 rounded-full bg-gradient-to-br from-foreground to-graphite" />
              Elite iPhones
            </div>
            <p className="mt-4 text-sm text-muted-foreground">Pakistan's most trusted destination for premium iPhones and accessories.</p>
            <div className="mt-4 space-y-1 text-sm text-muted-foreground">
              <p><span className="text-foreground font-medium">Owner:</span> Muhammad Mujahhid</p>
              <p>Dream Housing Society, Lahore</p>
              <p><a href="tel:+923191883227" className="hover:text-foreground transition-smooth">+92 319 1883227</a></p>
            </div>
            <div className="mt-5 flex gap-3 text-muted-foreground">
              {[Instagram, Facebook, Twitter, Youtube].map((I, i) => (
                <a key={i} href="#" aria-label="social" className="hover:text-foreground transition-smooth"><I className="h-5 w-5" /></a>
              ))}
            </div>
          </div>
          {cols.map((c) => (
            <div key={c.title}>
              <h4 className="text-sm font-semibold mb-4">{c.title}</h4>
              <ul className="space-y-3 text-sm text-muted-foreground">
                {c.links.map((l) => <li key={l}><a href="#" className="hover:text-foreground transition-smooth">{l}</a></li>)}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-12 flex flex-col md:flex-row gap-4 items-start md:items-center justify-between border-t border-border pt-6 text-xs text-muted-foreground">
          <div className="flex items-center gap-2"><MapPin className="h-4 w-4" /> Dream Housing Society, Lahore, Pakistan</div>
          <p>© {new Date().getFullYear()} Elite iPhones. All rights reserved.</p>
        </div>
      </div>

      <a
        href="https://wa.me/923191883227"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp"
        className="fixed bottom-6 right-6 z-40 inline-flex h-14 w-14 items-center justify-center rounded-full bg-[hsl(142,70%,45%)] text-white shadow-glow hover:scale-110 transition-smooth"
      >
        <MessageCircle className="h-6 w-6" />
      </a>
    </footer>
  );
};
