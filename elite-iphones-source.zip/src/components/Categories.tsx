import { Smartphone, Headphones, RefreshCw } from "lucide-react";

const cats = [
  { icon: Smartphone, title: "iPhones", desc: "New & pre-owned. PTA approved." },
  { icon: Headphones, title: "Accessories", desc: "AirPods, chargers, cases & more." },
  { icon: RefreshCw, title: "Refurbished", desc: "Certified. Tested. Warrantied." },
];

export const Categories = () => {
  return (
    <section id="accessories" className="container mx-auto px-6 py-20">
      <div className="mb-12 text-center">
        <h2 className="text-4xl md:text-5xl font-semibold text-gradient">Shop by category</h2>
      </div>
      <div className="grid gap-6 md:grid-cols-3">
        {cats.map(({ icon: Icon, title, desc }) => (
          <a key={title} href="#" className="group rounded-3xl bg-secondary/60 p-10 transition-smooth hover:bg-secondary hover:-translate-y-1">
            <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-background shadow-card-elite">
              <Icon className="h-6 w-6 text-accent" />
            </div>
            <h3 className="mt-6 text-2xl font-semibold">{title}</h3>
            <p className="mt-2 text-muted-foreground">{desc}</p>
            <span className="mt-6 inline-block text-accent text-sm font-medium">Browse all →</span>
          </a>
        ))}
      </div>
    </section>
  );
};
