import { ShoppingBag, Search, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "./ThemeToggle";

const links = ["iPhone", "Accessories", "Refurbished", "Trade-In", "Support"];

export const Navbar = () => {
  return (
    <header className="sticky top-0 z-50 w-full glass">
      <nav className="container mx-auto flex h-14 items-center justify-between px-6">
        <a href="#" className="flex items-center gap-2 font-semibold tracking-tight">
          <span className="inline-block h-6 w-6 rounded-full bg-gradient-to-br from-foreground to-graphite" />
          <span>Elite iPhones</span>
        </a>
        <ul className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
          {links.map((l) => (
            <li key={l}>
              <a href={`#${l.toLowerCase()}`} className="hover:text-foreground transition-smooth">{l}</a>
            </li>
          ))}
        </ul>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="rounded-full hidden sm:inline-flex"><Search className="h-[1.1rem] w-[1.1rem]" /></Button>
          <ThemeToggle />
          <Button variant="ghost" size="icon" className="rounded-full relative">
            <ShoppingBag className="h-[1.1rem] w-[1.1rem]" />
            <span className="absolute -top-0.5 -right-0.5 h-4 w-4 rounded-full bg-accent text-[10px] font-medium text-accent-foreground flex items-center justify-center">2</span>
          </Button>
          <Button variant="ghost" size="icon" className="rounded-full md:hidden"><Menu className="h-[1.1rem] w-[1.1rem]" /></Button>
        </div>
      </nav>
    </header>
  );
};
