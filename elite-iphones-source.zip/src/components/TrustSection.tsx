import { ShieldCheck, Truck, Award, Headset } from "lucide-react";

const items = [
  { icon: ShieldCheck, title: "100% Original", desc: "Authentic Apple. Verified IMEI on every device." },
  { icon: Award, title: "1-Year Warranty", desc: "Comprehensive coverage included with every purchase." },
  { icon: Truck, title: "Fast Delivery", desc: "Free same-day delivery in major cities across Pakistan." },
  { icon: Headset, title: "Expert Support", desc: "Talk to a real iPhone specialist, 7 days a week." },
];

export const TrustSection = () => {
  return (
    <section id="support" className="bg-secondary/40 py-20">
      <div className="container mx-auto px-6">
        <div className="text-center mb-14">
          <p className="text-sm font-medium text-accent">Why Elite</p>
          <h2 className="mt-2 text-4xl md:text-5xl font-semibold text-gradient">Premium service. Pure trust.</h2>
        </div>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {items.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="text-center">
              <div className="mx-auto inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-background shadow-card-elite">
                <Icon className="h-6 w-6 text-accent" />
              </div>
              <h3 className="mt-5 text-lg font-semibold">{title}</h3>
              <p className="mt-2 text-sm text-muted-foreground max-w-xs mx-auto">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
