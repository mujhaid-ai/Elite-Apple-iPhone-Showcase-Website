import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { Marquee } from "@/components/Marquee";
import { FeaturedProducts } from "@/components/FeaturedProducts";
import { PromoBanners } from "@/components/PromoBanners";
import { Categories } from "@/components/Categories";
import { TrustSection } from "@/components/TrustSection";
import { Testimonials } from "@/components/Testimonials";
import { Newsletter } from "@/components/Newsletter";
import { Footer } from "@/components/Footer";
import { useEffect } from "react";

const Index = () => {
  useEffect(() => {
    document.title = "Elite iPhones — Premium iPhones in Pakistan";
    const meta = document.querySelector('meta[name="description"]') || (() => {
      const m = document.createElement("meta");
      m.name = "description";
      document.head.appendChild(m);
      return m;
    })();
    meta.setAttribute("content", "Shop the latest iPhone 16 Pro, iPhone 16, AirPods and refurbished Apple devices. PTA approved, 1-year warranty, free delivery across Pakistan.");
  }, []);

  return (
    <main>
      <Navbar />
      <Hero />
      <Marquee />
      <FeaturedProducts />
      <PromoBanners />
      <Categories />
      <TrustSection />
      <Testimonials />
      <Newsletter />
      <Footer />
    </main>
  );
};

export default Index;
